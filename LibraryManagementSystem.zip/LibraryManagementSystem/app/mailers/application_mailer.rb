class ApplicationMailer < ActionMailer::Base
  default from: 'yourbookrequests@gmail.com'
  layout 'mailer'
end
