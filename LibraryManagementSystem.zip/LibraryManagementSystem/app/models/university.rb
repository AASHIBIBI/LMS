class University < ActiveRecord::Base
    UNIVERSITY_TYPES = ["NCSU","UNCC", "Duke"]
end