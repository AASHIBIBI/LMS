module HomePageHelper
end
